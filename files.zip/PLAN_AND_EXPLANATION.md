# Mini Project 2: plan and what to say in the evaluation

## 1. What the project asks (in plain words)
Take a big agriculture dataset, clean it, store it in SQL, answer 10 questions with SQL, do EDA charts in Python,
and build an interactive dashboard (Power BI in the brief; Plotly is also named in the approach).

## 2. How the pieces connect
CSV (16,146 rows x 80 columns) -> pandas cleans and reshapes -> SQLite database (4 tables + 1 view) -> SQL queries -> Plotly/Streamlit dashboard
-> the same clean data exported to `powerbi/` for the Power BI report.

## 3. What is in the data (be able to say this)
- 311 districts, 20 states, 1966-2017, about 310 districts per year, no duplicates.
- 29 crops / crop groups, each with area (1000 ha), production (1000 tons) and yield (kg/ha). Fruits, vegetables, potatoes, onion and fodder have area only.
- `-1` means missing (13,132 values). A district can have 0 for a crop it does not grow.
- Yield = production / area x 1000. This was checked: it matches the file's yield in 99.7% of rice rows.

## 4. Data-quality problems we found and fixed (strong talking points)
1. Missing values coded as -1 -> NULL.
2. The ready-made OILSEEDS column had only 31 districts in 2016-17 and zeros for Tamil Nadu in 2009-12, which made Tamil Nadu look like +268% growth. We rebuilt it from the oilseed crops and the false jump disappeared.
3. State yields are weighted (total production / total area). Averaging district yields would give small districts the same weight as huge ones.
4. State names follow 2017 boundaries, so Telangana, Chhattisgarh, Jharkhand and Uttarakhand can be compared over 50 years.

## 5. Schedule
| When | Do |
|---|---|
| Nov 5 (today) | Run it, check every page, read `sql_queries.sql`, push to GitHub, submit |
| Nov 5-6 | Power BI: see POWERBI_GUIDE.md (needs Windows) |
| Nov 6 | Practice explaining: the 10 queries and the 4 problems above |

## 6. Questions an evaluator may ask
- Why long format? One row per district-year-crop makes filtering by crop a simple WHERE and works well in Power BI.
- Why SQLite? No installation; the SQL runs on PostgreSQL/MySQL with small changes (date/sqrt functions).
- How did you define "last 5 years"? 2013-17 vs 2008-12 averages.
- Why is Jharkhand's growth 829%? Its starting base is tiny (about 9,500 tons), so a small increase is a huge percentage.
- Is the forecast reliable? No, it is a trend line only. Real forecasting needs weather, prices and policy.
- What would you improve? Add weather/rainfall data, a state map with GeoJSON, and a proper ML model.
